// src/components/planningComponents/SelectSubjects.jsx
import React, { useEffect, useState } from "react";

export default function SelectSubjects({ onSelect, onCancel }) {
  const [areas, setAreas] = useState([]);
  const [selectedId, setSelectedId] = useState(null);

  // Cargar materias
  useEffect(() => {
    fetch("http://localhost:8080/api/areas")
      .then((res) => res.json())
      .then(setAreas)
      .catch((e) => console.error("Error cargando áreas:", e));
  }, []);

  const handleSelect = (area) => {
    setSelectedId(area.idArea);
    onSelect(area);  // ← ENVÍA SOLO UNA MATERIA, NO UN ARRAY
  };

  return (
    <div style={{ marginTop: "1rem" }}>
      <h3>Selecciona una materia para este día:</h3>

      <div style={{
        display: "flex",
        flexWrap: "wrap",
        gap: ".6rem",
        marginTop: "1rem"
      }}>
        {areas.map((area) => (
          <button
            key={area.idArea}
            onClick={() => handleSelect(area)}
            className={
              selectedId === area.idArea
                ? "button-primary"
                : "button-ghost"
            }
          >
            {area.name}
          </button>
        ))}
      </div>

      <button
        className="button-ghost"
        style={{ marginTop: "1.5rem" }}
        onClick={onCancel}
      >
        Cancelar
      </button>
    </div>
  );
}
