// src/pages/planningPages/DailyPlanPage.jsx
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import SelectSubjects from "../../components/planningComponents/SelectSubjects";
import DailyPlanForm from "../../components/planningComponents/DailyPlanForm";

export default function DailyPlanPage(onCancel) {
  const { fecha } = useParams();
  const [materiasDia, setMateriasDia] = useState([]);
  const [agregandoMateria, setAgregandoMateria] = useState(false);
  const [editando, setEditando] = useState(null);

  // 📌 Cargar materias guardadas del día
  const loadMaterias = async () => {
    const res = await fetch(`http://localhost:8080/api/daily-plan/by-date/${fecha}`);
    const data = await res.json();
    setMateriasDia(data);
  };

  useEffect(() => {
    loadMaterias();
  }, [fecha]);

  return (
    <div style={{ padding: "2rem" }}>
      <button
        type="button"
        onClick={onCancel}
        className="button-ghost"
        style={{ marginBottom: "1rem" }}
      >
        ⬅ Volver
      </button>
      <h2>
        Planeación del día: <span style={{ color: "#007bff" }}>{fecha}</span>
      </h2>

      {/* Botón agregar materia */}
      {!agregandoMateria && !editando && (
        <button
          onClick={() => setAgregandoMateria(true)}
          className="button-primary"
          style={{ marginTop: "1rem" }}
        >
          + Agregar materia del día
        </button>
      )}

      {/* Lista de materias del día */}
      {!agregandoMateria && !editando && (
        <div style={{ marginTop: "2rem" }}>
          <h3>Materias asignadas hoy:</h3>

          {materiasDia.length === 0 && <p>📌 No hay materias asignadas a este día.</p>}

          {materiasDia.map((m) => (
            <div
              key={m.idPlan}
              style={{
                padding: "1rem",
                border: "1px solid #ccc",
                borderRadius: "8px",
                marginBottom: ".8rem",
              }}
            >
              <strong>{m.area.name}</strong> —{" "}
              {m.state === "COMPLETO" ? "🟢 COMPLETO" : "🟡 INCOMPLETO"}

              <button
                className="button-ghost"
                onClick={() => setEditando({
                  ...m,
                  area: m.area ?? m.areaId ?? m.areaDTO ?? null
                })
                }
                style={{ marginLeft: "1rem" }}
              >
                Editar
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Seleccionar materia nueva */}
      {agregandoMateria && (
        <SelectSubjects
          onSelect={(materia) => {
            setAgregandoMateria(false);

            // 🔹 Crear un plan NUEVO vacío
            setEditando({
              idPlan: null,
              area: materia,
              date: fecha,
              state: "INCOMPLETO",
              idDba: null,
              idCompetencies: null,
              idLearning: null,
              idThematicAxes: null,
              idEvaluationCriteria: null,
              idSiA: null,
              idResources: null,
              observations: ""
            });
          }}
          onCancel={() => setAgregandoMateria(false)}
        />
      )}

      {/* Formulario de planeación */}
      {editando && (
        <DailyPlanForm
          area={editando.area}
          fecha={fecha}
          plan={editando}
          onSaved={() => {
            setEditando(null);
            loadMaterias();
          }}
          onCancel={() => setEditando(null)}
        />
      )}
    </div>
  );
}
